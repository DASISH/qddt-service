package no.nsd.qddt.security.jwt;

import no.nsd.qddt.security.MyUserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


/**
 * @author Stig Norland
 */
public class JwtAuthenticationTokenFilter extends OncePerRequestFilter {


//    @Autowired
//    private UserService userService;

    @Autowired
//    @Qualifier("myUserDetailsService")
    private MyUserDetailsServiceImpl myUserService;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Value("${jwt.header}")
    private String tokenHeader = "Authorization";

    /**
     * Checks if JWT present and valid
     *
     * @param request  with JWT
     * @param response
     * @param chain
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {

        String authToken = request.getHeader( this.tokenHeader );
        if (authToken != null && authToken.startsWith( "Bearer " ))
            authToken = authToken.substring( 6 ).trim();

        String username = jwtTokenUtil.getUsernameFromToken( authToken );

        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
//            return   userService.findByEmail(name.toLowerCase().trim() );
            UserDetails userDetails = this.myUserService.loadUserByUsername( username.toLowerCase().trim() );

            if (jwtTokenUtil.validateToken( authToken, userDetails )) {
                UsernamePasswordAuthenticationToken authentication =
                    new UsernamePasswordAuthenticationToken( userDetails, null, userDetails.getAuthorities() );

                authentication.setDetails( new WebAuthenticationDetailsSource().buildDetails( request ) );
                SecurityContextHolder.getContext().setAuthentication( authentication );
            }
        }
        chain.doFilter( request, response );
    }
}
