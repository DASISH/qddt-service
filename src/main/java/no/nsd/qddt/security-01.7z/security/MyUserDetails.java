package no.nsd.qddt.security;

import no.nsd.qddt.domain.user.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


@Service
public class MyUserDetails implements UserDetailsService {

  @Autowired
  private UserRepository userRepository;

  @Override
  public UserDetails loadUserByUsername(String name) throws UsernameNotFoundException {
    return (UserDetails) userRepository.findByEmailIgnoreCase(name.toLowerCase().trim() );
  }


//  @Override
//  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//    final User user = userRepository.findByEmailIgnoreCase(username.trim().toLowerCase( Locale.ROOT ));
//
//    if (user == null) {
//      throw new UsernameNotFoundException("User '" + username + "' not found");
//    }
//
//    return org.springframework.security.core.userdetails.User//
//        .withUsername(username)//
//        .password(user.getPassword())//
//        .authorities(user.getRoles())//
//        .accountExpired(false)//
//        .accountLocked(false)//
//        .credentialsExpired(false)//
//        .disabled(false)//
//        .build();
//  }

}
