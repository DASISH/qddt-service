package no.nsd.qddt.security;


import no.nsd.qddt.domain.classes.exception.InvalidPasswordException;
import no.nsd.qddt.domain.classes.exception.UserNotFoundException;
import no.nsd.qddt.domain.user.UserService;
import no.nsd.qddt.security.MyUserDetails;
import no.nsd.qddt.security.jwt.JwtAuthenticationRequest;
import no.nsd.qddt.security.jwt.JwtAuthenticationResponse;
import no.nsd.qddt.security.jwt.JwtTokenUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import javax.persistence.NoResultException;
import javax.servlet.http.HttpServletRequest;

import static no.nsd.qddt.config.SecurityConfiguration.passwordEncoderBean;
import static no.nsd.qddt.security.WebSecurityConfig.passwordEncoderBean;

/**
 * AuthController provides signup, signin and token refresh methods
 * @author saka7
 */
@RestController
public class AuthController  {

    @Value("${auth.header:Authorization}")
    private String tokenHeader;

//    public final static String SIGNUP_URL = "auth/signup";
    public final static String SIGNIN_URL = "auth/signin";
    public final static String REFRESH_TOKEN_URL = "auth/token/refresh";

    private final AuthenticationManager authManager;

    private final JwtTokenProvider jwtUtil;

    private final UserService userService;

    public AuthController(AuthenticationManager authManager, JwtTokenProvider jwtUtil, UserService userService) {
        this.authManager = authManager;
        this.jwtUtil = jwtUtil;
        this.userService = userService;
    }


    /**
     * Returns authentication token for given user
     * @param authenticationRequest with username and password
     * @return generated JWT
     * @throws AuthenticationException if token is invalid
     */
    @PostMapping(value = SIGNIN_URL)
    public ResponseEntity getAuthenticationToken(@RequestBody JwtAuthenticationRequest authenticationRequest) throws AuthenticationException {

        final String email = authenticationRequest.getEmail();
        final String password = authenticationRequest.getPassword();
        UserDetails userDetails;
//        LOG.info("getAuthenticationToken " + email);

        try {
            userDetails = ()userService.findByEmail( email);
        } catch (UsernameNotFoundException | NoResultException ex) {
            throw new UserNotFoundException(email);
        } catch (Exception ex) {
//            LOG.error(ex.getMessage());
            return new ResponseEntity<>(ex, HttpStatus.BAD_REQUEST);
        }

        if(!passwordEncoderBean().matches(password, userDetails.getPassword())) {
            throw new InvalidPasswordException(userDetails.getUsername());
        }

        final Authentication authentication = authManager.authenticate(
            new UsernamePasswordAuthenticationToken(userDetails.getUsername(), password)
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);
        final String token = jwtUtil.createToken(userDetails);
        return ResponseEntity.ok(new JwtAuthenticationResponse(token));
    }

    /**
     * Refreshes token
     * @param request with old JWT
     * @return Refreshed JWT
     */
    @RequestMapping(REFRESH_TOKEN_URL)
    public ResponseEntity refreshAuthenticationToken(HttpServletRequest request) {
//        String token = request.getHeader(tokenHeader);
//        LOG.info("refreshAuthenticationToken");

        String refreshedToken = jwtUtil.generateToken( (UserDetails) SecurityContextHolder.getContext().getAuthentication().getDetails() );
        return ResponseEntity.ok(new JwtAuthenticationResponse(refreshedToken));
    }

}
